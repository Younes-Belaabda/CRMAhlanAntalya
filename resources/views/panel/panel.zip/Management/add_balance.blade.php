@extends('panel.layouts.base',['is_main'=>true])
@section('sub_title','View Data User')
@section('content')
    @push('panel_css')
    @endpush
    <div class="container-fluid py-4">
        <div class="card mb-4">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0">{{ __('User Balance') }}</h6>
            </div>
            <div class="card-body pt-4 p-3">
                <form action="{{ Route('panel.users.add_balance' , @$user->id ) }}" method="POST" role="form text-left">
                  @csrf
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="amount" class="form-control-label">{{ __('Amount') }}</label>
                                <div class="@error('amount')border border-danger rounded-3 @enderror">
                                    <input name="amount" class="form-control" type="text" placeholder="amount" required
                                        id="amount" value="{{ old('amount') }}">
                                </div>
                                @error('amount') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="currency" class="form-control-label">{{ __('Currency') }}</label>
                                <div class="@error('currency') border border-danger rounded-3 @enderror">
                                    <select name="currency" class="form-control" id="currency" required>
                                      <option value="">Choose</option>
                                      <option value="$" {{ isset($data->type) && $data->type == "$" ? 'selected' : '' }}>$</option>
                                      <option value="TL" {{ isset($data->type) && $data->type == "TL" ? 'selected' : '' }}>TL</option>
                                      <option value="€" {{ isset($data->type) && $data->type == "€" ? 'selected' : '' }}>€</option>
                                      <option value="£" {{ isset($data->type) && $data->type == "£" ? 'selected' : '' }}>£</option>
                                    </select>
                                </div>
                                @error('currency') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="date" class="form-control-label">{{ __('Date') }}</label>
                                <div class="@error('date')border border-danger rounded-3 @enderror">
                                    <input name="date" class="form-control" type="date" placeholder="date" required
                                        id="date" value="{{ old('date') }}">
                                </div>
                                @error('date') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn bg-gradient-dark btn-md mt-4 mb-4">{{ 'Save Changes' }}</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0">{{ __('User Balance') . " - " }} <b>{{@$user->full_name}}</b></h6>
                <label>Currnet cridet $: {{$user->sum("$")}}</label>
                <label>Currnet cridet TL: {{$user->sum("TL")}}</label>
                <label>Currnet cridet €: {{$user->sum("€")}}</label>
                <label>Currnet cridet £: {{$user->sum("£")}}</label>
            </div>
            <div class="card-body pt-4 p-3">
                <div class="table-responsive p-0">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    ID
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Ammount
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Currency
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Date
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Admin
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($balances as $key => $row)
                            <tr>
                                <td class="ps-4">
                                    <p class="text-xs font-weight-bold mb-0">{{ $key + 1 }}</p>
                                </td>
                                <td class="ps-4">
                                    <p class="text-xs font-weight-bold mb-0">{{  $row->amount }}</p>
                                </td>
                                <td class="ps-4">
                                    <p class="text-xs font-weight-bold mb-0">{{  $row->currency }}</p>
                                </td>
                                <td class="ps-4">
                                    <p class="text-xs font-weight-bold mb-0">{{  date("d-m-Y", strtotime($row->date)) }}</p>
                                </td>
                                <td class="ps-4">
                                    <p class="text-xs font-weight-bold mb-0">{{  $row->m_user->full_name }}</p>
                                </td>
                                <td class="text-center">
                                    <a data-url="{{ route('panel.users.balance_delete' , $row->users_balance_id ) }}" class="mx-3 delete" data-bs-toggle="tooltip"
                                        data-bs-original-title="Delete Balance">
                                        <i class="cursor-pointer fas fa-trash text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  @push('panel_js')

  @endpush
@stop
