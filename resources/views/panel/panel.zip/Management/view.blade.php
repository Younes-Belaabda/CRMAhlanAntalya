@extends('panel.layouts.base',['is_main'=>true])
@section('sub_title','View Users')
@section('content')
    @push('panel_css')
    @endpush

    <div class="row">
        <div class="col-12">
            <div class="card mb-4 mx-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-1">All Accounts</h5>
                        </div>
                        <a href="{{ route('panel.users.add_new') }}" class="btn bg-gradient-primary btn-sm mb-2" type="button">+&nbsp; New Account</a>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        ID
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        User Name
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Full Name
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Email
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Type
                                    </th>
                                    <th class="last-child text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Status
                                    </th>
                                    <th class="last-child text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                              @foreach($data as $key => $row)
                                <tr>
                                    <td class="ps-4">
                                        <p class="text-xs font-weight-bold mb-0">{{ $key + 1 }}</p>
                                    </td>
                                    <td>
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->user_name }}</p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->full_name  }}</p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->email }}</p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->Typename }}</p>
                                    </td>
                                    <td class="text-center">
                                        <div class="form-check form-switch ps-0 check_center">
                                            <input class="form-check-input ms-auto is-displayed"
                                              data-url="{{ route('panel.users.change_status' , $row->id) }}"
                                              type="checkbox" id="flexSwitchCheckDefault"
                                              {{ $row->status == 1 ? 'checked' : ''}}>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        @if($row->type == "2")
                                        <a href="{{ route('panel.users.add_balance' , $row->id) }}" class="mx-1" data-bs-toggle="tooltip"
                                            data-bs-original-title="Balance Account">
                                            <i class="fa fa-usd text-info"></i>
                                        </a>
                                        @endif
                                        <a href="{{ route('panel.users.add_new' , $row->id) }}" class="mx-1" data-bs-toggle="tooltip"
                                            data-bs-original-title="Edit Account">
                                            <i class="fas fa-user-edit text-secondary"></i>
                                        </a>
                                        <a data-url="{{ route('panel.users.delete' , $row->id) }}" class="mx-1 delete" data-bs-toggle="tooltip"
                                            data-bs-original-title="Delete Account">
                                            <i class="cursor-pointer fas fa-trash text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
  @push('panel_js')

  @endpush
@stop
