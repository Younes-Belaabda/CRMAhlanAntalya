@extends('panel.layouts.base',['is_main'=>true])
@section('sub_title','Home')
@section('content')
    @push('panel_css')
    @endpush

  @section('panel_js')

  @endsection
  @stop
