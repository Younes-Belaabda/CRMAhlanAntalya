@extends('panel.layouts.base',['is_main'=>true])
@section('sub_title','View Data Movement')
@section('content')
    @push('panel_css')
    @endpush
    <div class="container-fluid py-4">
        <div class="card">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0">{{ __('User Movement') }}</h6>
            </div>
            <div class="card-body pt-4 p-3">
                <form action="{{ Route('panel.movement.add_new' , @$data->movement_id ) }}" method="POST" role="form text-left">
                  @csrf
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="customer" class="form-control-label">{{ __('Name/Surname') }}</label>
                                <div class="@error('customer')border border-danger rounded-3 @enderror">
                                    <input name="customer" class="form-control" type="text" placeholder="customer" required
                                        id="customer" value="{{ isset($data->customer) ? $data->customer : old('customer') }}">
                                </div>
                                @error('customer') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="date" class="form-control-label">{{ __('date') }}</label>
                                <div class="@error('date')border border-danger rounded-3 @enderror">
                                    <input name="date" class="form-control datepicker" type="text" required
                                        id="date" value="{{ isset($data->date) ? $data->date : old('date') }}">
                                </div>
                                @error('date') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="description" class="form-control-label">{{ __('description') }}</label>
                                <div class="@error('description')border border-danger rounded-3 @enderror">
                                    <input name="description" class="form-control" type="text"
                                        placeholder="description" id="description" required value="{{ isset($data->description) ? $data->description : old('description') }}">
                                </div>
                                @error('description') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="type" class="form-control-label">{{ __('type') }}</label>
                                <div class="@error('type') border border-danger rounded-3 @enderror">
                                    <select name="type" class="select form-control" id="type" required>
                                      <option value="">Choose</option>
                                      <option value="Airport Pickup & Transfers" {{ isset($data->type) && $data->type == "Airport Pickup & Transfers" ? 'selected' : '' }}>Airport Pickup & Transfers</option>
                                      <option value="Driver Tours" {{ isset($data->type) && $data->type == "Driver Tours" ? 'selected' : '' }}>Driver Tours</option>
                                      <option value="Group Tours" {{ isset($data->type) && $data->type == "Group Tours" ? 'selected' : '' }}>Group Tours</option>
                                      <option value="Car Rental" {{ isset($data->type) && $data->type == "Car Rental" ? 'selected' : '' }}>Car Rental</option>
                                      <option value="Hotels/Apart-hotels" {{ isset($data->type) && $data->type == "Hotels/Apart-hotels" ? 'selected' : '' }}>Hotels/Apart-hotels</option>
                                      <option value="Other Services" {{ isset($data->type) && $data->type == "Other Services" ? 'selected' : '' }}>Other Services</option>
                                    </select>
                                </div>
                                @error('type') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="color" class="form-control-label">{{ __('color') }}</label>
                                <div class="@error('color') border border-danger rounded-3 @enderror">
                                    <select name="color" class="select form-control" id="color">
                                      <option value="">Choose</option>
                                      <option value="1" {{ isset($data->color) && $data->color == "1" ? 'selected' : '' }}>Red</option>
                                      <option value="2" {{ isset($data->color) && $data->color == "2" ? 'selected' : '' }}>Yallow</option>
                                      <option value="3" {{ isset($data->color) && $data->color == "3" ? 'selected' : '' }}>Green</option>
                                      <option value="4" {{ isset($data->color) && $data->color == "4" ? 'selected' : '' }}>blue</option>
                                    </select>
                                </div>
                                @error('color') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="country_id" class="form-control-label">{{ __('country') }}</label>
                                <div class="@error('country_id') border border-danger rounded-3 @enderror">
                                    <select name="users" class="select form-control" id="country_id">
                                      <option value="">Choose</option>
                                      @foreach($countries as $key => $row)
                                        <option value="{{$row->countries_id}}">{{$row->name}}</option>
                                      @endforeach
                                    </select>
                                </div>
                                @error('country_id') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="price" class="form-control-label">{{ __('price') }}</label>
                                <div class="@error('price')border border-danger rounded-3 @enderror">
                                    <input name="price" class="form-control" type="text" placeholder="price" required
                                        id="price" value="{{ isset($data->price) ? $data->price : old('price') }}">
                                </div>
                                @error('price') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="price_type" class="form-control-label">{{ __('Currency') }}</label>
                                <div class="@error('price_type') border border-danger rounded-3 @enderror">
                                    <select name="price_type" class="select form-control" id="price_type" required>
                                      <option value="">Choose</option>
                                      <option value="$" {{ isset($data->price_type) && $data->price_type == "$" ? 'selected' : '' }}>$</option>
                                      <option value="TL" {{ isset($data->price_type) && $data->price_type == "TL" ? 'selected' : '' }}>TL</option>
                                      <option value="€" {{ isset($data->price_type) && $data->price_type == "€" ? 'selected' : '' }}>€</option>
                                      <option value="£" {{ isset($data->price_type) && $data->price_type == "£" ? 'selected' : '' }}>£</option>
                                    </select>
                                </div>
                                @error('price_type') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        @if(isset($data->price_type))
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="net" class="form-control-label">{{ __('net') }}</label>
                                <div class="@error('net')border border-danger rounded-3 @enderror">
                                    <input name="net" class="form-control" type="text" placeholder="optional"
                                        id="net" value="{{ isset($data->net) ? $data->net : old('net') }}">
                                </div>
                                @error('net') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="revenue" class="form-control-label">{{ __('Profit') }}</label>
                                <div class="@error('net')border border-danger rounded-3 @enderror">
                                    <input name="revenue" class="form-control" type="text" placeholder="optional"
                                        id="revenue" value="{{ isset($data->revenue) ? $data->revenue : old('revenue') }}">
                                </div>
                                @error('revenue') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        @endif
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="commission" class="form-control-label">{{ __('commission') }}</label>
                                <div class="@error('commission')border border-danger rounded-3 @enderror">
                                    <input name="commission" class="form-control" type="text" placeholder="optional"
                                        id="commission" value="{{ isset($data->commission) ? $data->commission : old('commission') }}">
                                </div>
                                @error('commission') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <!-- <div class="col-md-3">
                            <div class="form-group">
                                <label for="status" class="form-control-label">{{ __('Status') }}</label>
                                <div class="@error('status') border border-danger rounded-3 @enderror">
                                    <select name="status" class="select form-control" id="status" required>
                                      <option value="">Choose</option>
                                      <option value="1" {{ isset($data->status) && $data->status == 1 ? 'selected' : '' }}>Paid</option>
                                      <option value="0" {{ isset($data->status) && $data->status == 0 ? 'selected' : '' }}>Not Paid</option>
                                    </select>
                                </div>
                                @error('status') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div> -->

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="users" class="form-control-label">{{ __('users') }}</label>
                                <div class="@error('users') border border-danger rounded-3 @enderror">
                                    <select name="users[]" class="select form-control" multiple id="users" required>
                                      <option value="">Choose</option>
                                      @foreach($users as $key => $row)
                                        <?php $select = ""; ?>
                                        @if(isset($data->users) && $data->users != null)
                                            @foreach($data->users as $key => $row_users)
                                                <?php
                                                    if($row_users->id == $row->id){
                                                        $select = "selected";
                                                    }
                                                ?>
                                            @endforeach
                                        @endif
                                        <option value="{{$row->id}}" {{ $select }}>{{$row->full_name}}</option>
                                      @endforeach
                                    </select>
                                </div>
                                @error('users') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="paybyus" class="form-control-label">{{ __('paybyus') }}</label>
                                <div class="@error('paybyus') border border-danger rounded-3 @enderror">
                                    <input name="paybyus" type="checkbox"
                                        {{ isset($data->paybyus) && $data->paybyus == "1" ? 'checked' : '' }}
                                        placeholder="paybyus" id="paybyus" value="1">
                                </div>
                                @error('paybyus') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                        </div>
                    </div>
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                User Movement Notification
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="to_user_id" class="form-control-label">{{ __('Accounts') }}</label>
                                                <div class="@error('to_user_id') border border-danger rounded-3 @enderror">
                                                    <select name="to_user_id" class="select form-control" id="to_user_id">
                                                    <option value="">Choose</option>
                                                        @foreach($nusers as $key => $row)
                                                            <option value="{{$row->id}}" {{ isset($data->notification) && $data->notification->to_user_id == $row->id ? 'selected' : '' }}>{{$row->full_name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="ntext" class="form-control-label">{{ __('Note Text') }}</label>
                                                <div class="@error('ntext')border border-danger rounded-3 @enderror">
                                                    <textarea  name="ntext" rows="4" class="form-control">{{ isset($data->notification) ? $data->notification->text : old('ntext') }}</textarea>
                                                </div>
                                                @error('ntext') <div class="text-danger">{{ $message }}</div> @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn bg-gradient-dark btn-md mt-4 mb-4">{{ 'Save Changes' }}</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
  @push('panel_js')

  @endpush
@stop
