<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta  name="keywords" content="Budget" />
      <meta  name="description" content="Budget" />
      <meta  itemprop="name" content="Budget" />
      <meta  itemprop="description" content="Budget" />
      <meta  itemprop="image" content="" />
      <meta  name="twitter:card" content="product" />
      <meta  name="twitter:site" content="@Budget" />
      <meta  name="twitter:title" content="Budget" />
      <meta  name="twitter:description" content="Budget" />
      <meta  name="twitter:creator" content="@Budget" />
      <meta  name="twitter:image" content="Budget" />
      <meta  property="fb:app_id" content="" />
      <meta  property="og:title" content="Budget" />
      <meta  property="og:type" content="article" />
      <meta  property="og:url" content="" />
      <meta  property="og:image" content="Budget" />
      <meta  property="og:description" content="Budget" />
      <meta  property="og:site_name" content="Budget" />

      <meta name="csrf-token" content="{{ csrf_token() }}" />

      <link rel="apple-touch-icon" sizes="76x76" href="{{admin_url('assets/img/apple-icon.png')}}">
      <link rel="icon" type="image/png" href="{{admin_url('assets/img/favicon.png')}}">
      <title>
          Portal - @yield('sub_title')
      </title>
      <!-- Fonts and icons     -->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
      <!-- Nucleo Icons -->
      <link href="{{admin_url('assets/css/nucleo-icons.css')}}" rel="stylesheet" />
      <link href="{{admin_url('assets/css/nucleo-svg.css')}}" rel="stylesheet" />
      <!-- Font Awesome Icons -->
      <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
      <link href="{{admin_url('assets/css/nucleo-svg.css')}}" rel="stylesheet" />
      <link href="{{admin_url('assets/css/nucleo-icons.css')}}" rel="stylesheet" />
      <!-- CSS Files -->
      <link href="{{admin_url('assets/css/bootstrap-datepicker.min.css')}}" rel="stylesheet" />
      <link id="pagestyle" href="{{admin_url('assets/css/soft-ui-dashboard.css')}}" rel="stylesheet" />
      <!-- Alpine -->
      <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
      <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
      <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
      @yield('panel_css')
      @yield('livewireHeader')
    <Style>
        label.form-control-label {
            text-transform: capitalize;
            text-align: center;
        }
        td.user {
            padding: 0;
        }
        td.user p {
            float: right;
            width: 100%;
            padding: 14px 5px;
        }
        /* .export_pdf {
            float: right;
            width: 90px;
            position: absolute;
            right: -20px;
            top: -16px;
        } */
    </style>
      <style>
      .check_center input{
        float: none !important;
        display: inline-block;
      }
      .check_center{
        text-align: center;
      }
      .navbar-vertical .navbar-nav>.nav-item .nav-link.active .icon {
            background-image: linear-gradient(310deg, #f53939 0%, #f53939 100%);
            font-size: 10px;
            width: 18px;
            height: 18px;
            border-radius: 5px;
            color: #fff;
        }
        .select2-selection.select2-selection--multiple{
            display: block;
            width: 100%;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #d2d6da;
            appearance: none;
            border-radius: 0.5rem;
            transition: box-shadow 0.15s ease, border-color 0.15s ease;
            height: 40.4px;
        }
        .select2-selection.select2-selection--single{
            display: block;
            width: 100%;
            padding: 0.5rem 0.75rem;
            font-size: 0.875rem;
            font-weight: 400;
            line-height: 1.4rem;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #d2d6da;
            appearance: none;
            border-radius: 0.5rem;
            transition: box-shadow 0.15s ease, border-color 0.15s ease;
            height: 40.4px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 40.4px;
        }
        table.table thead th {
            border: 1.4px solid #333 !important;
            background: #ddd;
            color: #000 !important;
            text-align: center;
            font-weight: bold !important;
            opacity: 1 !important;
            font-size: 10px !important;
            background: #ff9800;
            text-transform: capitalize !important;
        }
        .select2-container{
            width: 100% !important;
        }
        html {
            overflow-x: hidden;
        }
        #exp_pdf {
            background:#fff;
        }
        table.table tbody td {
            border: 1.4px solid #333 !important;
            background:#fff;
    text-align: center;
        }
        .table th:first-child {
            width: 5%;
        }
        .table th:not(:last-child)> :last-child>* {
            min-width: 10%;
        }
        .table th.last-child {
            width: 10%;
        }
        .navbar-vertical.navbar-expand-xs{
            max-width: 14rem !important;
        }
        .sidenav.fixed-left+.main-content {
            margin-left: 14.125rem;
        }
        .form-switch .form-check-input:checked {
            border-color: #4caf50;
            background-color: #4caf50;
        }
      </style>

  </head>

  <body class="g-sidenav-show bg-gray-100">

      @include('panel.layouts.navbars.auth.sidebar')
      @include('panel.layouts.navbars.auth.nav')

      @if(Session::has('message'))
      <div class="container-fluid py-4">
        <div class="alert alert-danger">
          <b class="text-white">{{ Session::get('message') }}</b>
        </div>
      </div>
      @endif
        @if(session()->has('success'))
        <div class="container-fluid py-4">
            <div class="alert alert-success">
              <b class="text-white">{{ session('success') }}</b>
            </div>
          </div>
        @endif
        @if(session()->has('info'))
        <div class="container-fluid py-4">
            <div class="alert alert-success">
              <b class="text-white">{{ session('info') }}</b>
            </div>
          </div>
        @endif
        @if(session()->has('danger'))
        <div class="container-fluid py-4">
          <div class="alert alert-danger">
            <b class="text-white">{{ session('danger') }}</b>
          </div>
        </div>
        @endif


      @yield('content')
      <main>
          <div class="container-fluid">
              <div class="row">
                  @include('panel.layouts.footers.auth.footer')
              </div>
          </div>
      </main>

      <!--   Core JS Files   -->
      <script src="{{admin_url('assets/js/core/popper.min.js')}}"></script>
      <script src="{{admin_url('assets/js/core/bootstrap.min.js')}}"></script>
      <script src="{{admin_url('assets/js/plugins/smooth-scrollbar.min.js')}}"></script>

    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"
        integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer"
    ></script>
        <!--   Core JS Files   -->
        <script src="{{admin_url('assets/js/html2canvas.min.js')}}"></script>

      <script>
          var win = navigator.platform.indexOf('Win') > -1;
          if (win && document.querySelector('#sidenav-scrollbar')) {
              var options = {
                  damping: '0.5'
              }
              Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
          }
      </script>
      <!-- Github buttons -->
      <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
      <script src="{{admin_url('assets/js/soft-ui-dashboard.min.js?v=1.0.2')}}"></script>
      @yield('livewireScripts')

      <!-- Latest compiled and minified JavaScript -->
      <script src="{{admin_url('assets/js/jquery.min.js')}}"></script>
      <script src="{{admin_url('assets/js/bootstrap-datepicker.min.js')}}"></script>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

      @yield('panel_js')
      <script>
        $(document).ready(function() {
            $('.select').select2();
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd'
            });
        });
          $(document).ready(function () {
              var ok_btn = 'Ok';
              var err_txt = 'An unexpected error occurred.. Please try again later';
              if (window.lang === 'en'){
                   ok_btn = 'Ok';
                  err_txt = 'Unknown Error .. Try Again';
              }
              function customSweetAlert(type ,title , html , func) {
                  var then_function = func || function () {
                  };
                  swal.fire({
                      title: '<span class="'+type+'">'+title+'</span>',
                      type: type ,
                      html : html ,
                      confirmButtonText: 'Ok',
                      confirmButtonColor: '#56ace0',
                      confirmButtonClass: "btn btn-secondary m-btn m-btn--wide"

                  }).then(then_function);
              }

              function errorCustomSweet() {
                  customSweetAlert(
                      'error',
                      err_txt
                  );
              }
              $(document).on('change','.is-displayed',function (e) {
                  // showLoader();
                  var url = $(this).data('url');
                  $.ajax({
                      url: url,
                      type: 'GET',
                      success: function (response) {
                        location.reload();
                          // table.ajax.reload();
                          // if (!response.status){
                          // }
                          // hideLoader();
                      },
                      error : function () {
                        errorCustomSweet();
                      }
                  });
              });
              $(document).on('click', '.delete', function (event) {
                  var delete_url = $(this).data('url');
                  event.preventDefault();
                  swal.fire({
                      title: '<span class="info">Are you sure to delete the selected item?</span>',
                      type: 'delete',
                      showCloseButton: true,
                      showCancelButton: true,
                      confirmButtonText: 'delete',
                      cancelButtonText: 'Close',
                      confirmButtonColor: '#56ace0',
                  }).then(function (value) {
                      if (!(value.dismiss === 'cancel')) {
                          $.ajax({
                              url: delete_url,
                              method: 'delete',
                              type: 'json',
                               data: {
                                     _token: '{{ csrf_token() }}'
                               },
                              success: function (response) {
                                  if (response.status) {
                                      customSweetAlert(
                                          'success',
                                          response.message,
                                          response.item,
                                          function (event) {
                                              //table.ajax.reload()
                                              location.reload();
                                          }
                                      );
                                  } else {
                                      customSweetAlert(
                                          'error',
                                          response.message,
                                          response.errors_object
                                      );
                                  }
                              },
                              error: function (response) {
                                  errorCustomSweet();
                              }
                          });
                      }
                  });
              });
          });
      </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

      <script>
                var doc = new jsPDF();
                var specialElementHandlers = {
                    '#editor': function (element, renderer) {
                        return true;
                    }
                };
                function CreatePDFfromHTML() {
                    var HTML_Width = $("#exp_pdf").width();
                    var HTML_Height = $("#exp_pdf").height();
                    var top_left_margin = 15;
                    var PDF_Width = HTML_Width + (top_left_margin * 2);
                    var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
                    var canvas_image_width = HTML_Width;
                    var canvas_image_height = HTML_Height;

                    var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

                    html2canvas($("#exp_pdf")[0]).then(function (canvas) {
                        var imgData = canvas.toDataURL("image/jpeg", 1.0);
                        var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
                        pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);
                        for (var i = 1; i <= totalPDFPages; i++) {
                            pdf.addPage(PDF_Width, PDF_Height);
                            pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
                        }
                        pdf.save("Export.pdf");
                        //$("#exp_pdf").hide();
                    });
                }
            $(document).ready(function() {
                $('.export_pdf').click(function(){
                    CreatePDFfromHTML();
                    // html2canvas($("#exp_pdf"), {
                    //     onrendered: function(canvas) {
                    //         var imgData = canvas.toDataURL(
                    //             'image/png');
                    //         var doc = new jsPDF('p', 'mm');
                    //         doc.addImage(imgData, 'PNG', 15, 15);
                    //         doc.save('sample-file.pdf');
                    //     }
                    // });
                    // doc.fromHTML($('#exp_pdf').html(), 15, 15, {
                    //     'width': 170,
                    //         'elementHandlers': specialElementHandlers
                    // });
                    // doc.save('sample-file.pdf');
                });
            });
        </script>
        <div id="editor"></div>
  </body>
</html>
