<footer class="footer pb-4">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-left">
                    © {{ now()->year }}
                </div>
            </div>
            <div class="col-lg-6">
            </div>
        </div>
    </div>
</footer>
