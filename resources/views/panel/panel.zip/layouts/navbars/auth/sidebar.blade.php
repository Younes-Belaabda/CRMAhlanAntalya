<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-left ms-3"
    id="sidenav-main">
    <!-- <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute right-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="{{ route('panel.dashboard') }}">
            <img src="{{admin_url('assets/img/logo-ct.png')}}" class="navbar-brand-img h-100" alt="...">
            <span class="ms-1 font-weight-bold">Budget</span>
        </a>
    </div>
    <hr class="horizontal dark mt-0"> -->
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.dashboard' ? 'active' : '' }}"
                    href="{{ route('panel.dashboard') }}">
                    <div
                        class="icon bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-home"></i>
                    </div>
                    <span class="nav-link-text ms-1">Home</span>
                </a>
            </li>
            <li class="nav-item mt-2">
                <h6 class="text-uppercase text-xs font-weight-bolder opacity-6">Movements</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.movement.view' || Route::currentRouteName() == 'panel.movement.add_new' ? 'active' : '' }}"
                    href="{{ route('panel.movement.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-arrows-alt ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.movement.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.movement.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">List Movements</span>
                </a>
            </li><li class="nav-item mt-2">
                <h6 class="text-uppercase text-xs font-weight-bolder opacity-6">General</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.cash.view' || Route::currentRouteName() == 'panel.cash.add_new' ? 'active' : '' }}"
                    href="{{ route('panel.cash.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-usd ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.cash.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.cash.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">Accounting Manager</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.debt.view' || Route::currentRouteName() == 'panel.debt.add_new' ? 'active' : '' }}"
                    href="{{ route('panel.debt.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-usd ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.debt.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.debt.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">Debt Manager</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.todolist.view' || Route::currentRouteName() == 'panel.todolist.add_new' || Route::currentRouteName() == 'panel.todolist.add_retweet' ? 'active' : '' }}"
                    href="{{ route('panel.todolist.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-list-ol ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.todolist.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.todolist.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">To Do List</span>
                </a>
            </li>
            <li class="nav-item mt-2">
                <h6 class="text-uppercase text-xs font-weight-bolder opacity-6">Accounts</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.users.view' || Route::currentRouteName() == 'panel.users.add_new' ? 'active' : '' }}"
                    href="{{ route('panel.users.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-users ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.users.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.users.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'panel.countries.view' || Route::currentRouteName() == 'panel.countries.add_new' ? 'active' : '' }}"
                    href="{{ route('panel.countries.view') }}">
                    <div
                        class="icon  bg-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-flag ps-2 pe-2 text-center
                        {{ in_array(request()->route()->getName(),['panel.countries.view']) ? 'text-white' : ( in_array(request()->route()->getName(),['panel.countries.add_new']) ? 'text-white' :'text-dark') }}"></i>
                    </div>
                    <span class="nav-link-text ms-1">Countries</span>
                </a>
            </li>

        </ul>
    </div>
</aside>
