@extends('panel.layouts.base',['is_main'=>true])
@section('sub_title','View Cash')
@section('content')
    @push('panel_css')
    @endpush

    <div class="row">
        <div class="col-12">
            <div class="card mb-4 mx-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-1">Filter Cash</h5>
                        </div>
                        <a href="{{ route('panel.cash.add_new') }}" class="btn bg-gradient-primary btn-sm mb-2" type="button">+&nbsp; New cash</a>
                    </div>
                </div>
                <div class="card-body px-4 pt-0 pb-2 mb-0">
                    <form action="{{ Route('panel.cash.view') }}" method="Get" role="form text-left">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="type" class="form-control-label">{{ __('Type') }}</label>
                                    <div class="@error('type') border border-danger rounded-3 @enderror">
                                        <select name="type" class="select form-control" id="type">
                                            <option value="">Choose</option>
                                            <option value="Income" {{ @$request['type'] == "Income" ? 'selected' : '' }}>Income</option>
                                            <option value="Expenses" {{ @$request['type'] == "Expenses" ? 'selected' : '' }}>Expenses</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="from_date" class="form-control-label">{{ __('From Date') }}</label>
                                    <div class="@error('from_date') border border-danger rounded-3 @enderror">
                                        <input class="form-control datepicker" name="from_date" value="{{@$request['from_date']}}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="to_date" class="form-control-label">{{ __('To Date') }}</label>
                                    <div class="@error('to_date') border border-danger rounded-3 @enderror">
                                        <input class="form-control datepicker" name="to_date" value="{{@$request['to_date']}}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="for_id" class="form-control-label">{{ __('Expenses type') }}</label>
                                    <div class="@error('for_id') border border-danger rounded-3 @enderror">
                                        <select name="for_id" class="select form-control" id="for_id">
                                        <option value="">Choose</option>
                                        <option value="0" {{ @$request['for_id'] == "0" ? 'selected' : '' }}>Expenses</option>
                                            @foreach($users as $key => $row)
                                                <option value="{{$row->id}}" {{ @$request['for_id'] == $row->id ? 'selected' : '' }}>{{$row->full_name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn bg-gradient-dark btn-md mt-1 mb-1">{{ 'Filter' }}</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card mb-4 mx-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-1">All Cash</h5>
                        </div>
                        <a class="btn bg-gradient-primary btn-sm mb-2 export_pdf" type="button">PDF</a>
                    </div>
                </div>
                <div id="exp_pdf" class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        ID
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Amount
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Date
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Expenses type
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Note
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Source of service
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Admin
                                    </th>
                                    <th class="last-child text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Status
                                    </th>
                                    <th class="last-child text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                              @foreach($data as $key => $row)
                                <tr>
                                    <td class="ps-4">
                                        <p class="text-xs font-weight-bold mb-0">{{ $key + 1 }}</p>
                                    </td>
                                    <td>
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->price_type." ".$row->price  }}</p>
                                    </td>
                                    <td class="ps-4">
                                        <p class="text-xs font-weight-bold mb-0">{{  date("d-m-Y", strtotime($row->date)) }}</p>
                                    </td>
                                    <td class="user">
                                        @if($row->for_id == "0")
                                        <p class="text-xs font-weight-bold mb-0"> Expenses</p>
                                        @else
                                            <p class="text-xs font-weight-bold mb-0" style="background:{{@$row->for_user->background}};color:{{@$row->for_user->color}}">{{ @$row->for_user->full_name }}</p>
                                        @endif
                                    </td>
                                    <td>
                                        <p class="text-xs font-weight-bold mb-0">{{ ($row->movement_id != null ? "Movement :: " : "") . $row->note }}</p>
                                    </td>
                                    <td class="ps-4">
                                        <p class="text-xs font-weight-bold mb-0">{{ $row->type }}</p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-xs font-weight-bold mb-0">{{ @$row->m_user->full_name }}</p>
                                    </td>
                                    <td class="text-center">
                                        @if($row->movement_id == null)
                                        <div class="form-check form-switch ps-0 check_center">
                                            <input class="form-check-input ms-auto is-displayed"
                                              data-url="{{ route('panel.cash.change_status' , $row->income_id) }}"
                                              type="checkbox" id="flexSwitchCheckDefault"
                                              {{ $row->status == 1 ? 'checked' : ''}}>
                                        </div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($row->movement_id == null)
                                        <a href="{{ route('panel.cash.add_new' , $row->income_id) }}" class="mx-1" data-bs-toggle="tooltip"
                                            data-bs-original-title="Edit cash">
                                            <i class="fas fa-user-edit text-secondary"></i>
                                        </a>
                                        <a data-url="{{ route('panel.cash.delete' , $row->income_id) }}" class="mx-1 delete" data-bs-toggle="tooltip"
                                            data-bs-original-title="Delete cash">
                                            <i class="cursor-pointer fas fa-trash text-danger"></i>
                                        </a>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
  @push('panel_js')

  @endpush
@stop
