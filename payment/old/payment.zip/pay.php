<?php 
    //var_dump("test");exit();
    $post = $_POST;
    var_dump($post);exit();
    $storekey="123456";
    $hashparams = $_POST["HASHPARAMS"];
    $hashparamsval = $_POST["HASHPARAMSVAL"];
    $hashparam = $_POST["HASH"];					
    $paramsval="";
    $index1=0;
    $index2=0;

    while($index1 < strlen($hashparams))
    {
        $index2 = strpos($hashparams,":",$index1);
        $vl = $_POST[substr($hashparams,$index1,$index2- $index1)];
        if($vl == null)
        $vl = "";
        $paramsval = $paramsval . $vl; 
        $index1 = $index2 + 1;
    }					
    $hashval = $paramsval.$storekey;

    $hash = base64_encode(pack('H*',sha1($hashval)));
    if ($hashparams != null)
    {
        if($paramsval != $hashparamsval || $hashparam != $hash) 	
        {
            var_dump("<font color=\"red\">Security warning. Hash values mismatch. </font>");
        }
        else
        {
            if($mdStatus =="1" || $mdStatus == "2" || $mdStatus == "3" || $mdStatus == "4")
            { 	
                var_dump("<font color=\"green\">3D Authentication is successful. </font>");
            }
            else						
            {
                var_dump("<font color=\"red\">3D authentication unsuccesful. </font>");
            }
        }
    }
    else
    {
        var_dump("<font color=\"red\">Hash values error. Please check parameters posted to 3D secure page. </font>");
    }
    exit();
?>